# JointsDetection > 2022-11-26 10:07pm
https://universe.roboflow.com/object-detection/jointsdetection

Provided by a Roboflow user
License: CC BY 4.0

